package template;

public abstract class Problem {

}
