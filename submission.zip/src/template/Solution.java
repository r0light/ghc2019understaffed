package template;

public abstract class Solution {

    public String provideSolution() {
	throw new UnsupportedOperationException();
    };

}
