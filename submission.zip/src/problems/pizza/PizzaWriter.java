package problems.pizza;

import template.Writer;

public class PizzaWriter extends Writer {

}
