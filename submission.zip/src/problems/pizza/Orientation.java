package problems.pizza;

public enum Orientation {

	H, V

}
